const fs = require('fs');
const path = require('path');

function replaceInFile(filePath) {
    let content = fs.readFileSync(filePath, 'utf8');
    let newContent = content
        .replace(/family=Rubik:ital,wght@0,300\.\.900;1,300\.\.900&display=swap/g, 'family=Inter:wght@300;400;500;600;700&display=swap')
        .replace(/'Rubik'/g, "'Inter'");
    if (content !== newContent) {
        fs.writeFileSync(filePath, newContent, 'utf8');
        console.log('Updated ' + filePath);
    }
}

function walkDir(dir) {
    fs.readdirSync(dir).forEach(file => {
        let fullPath = path.join(dir, file);
        if (fs.lstatSync(fullPath).isDirectory()) {
            walkDir(fullPath);
        } else if (fullPath.endsWith('.html') || fullPath.endsWith('.htm') || fullPath.endsWith('.css')) {
            replaceInFile(fullPath);
        }
    });
}

walkDir(__dirname);
